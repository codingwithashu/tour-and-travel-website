import { baseProcedure, createTRPCRouter } from "@/trpc/init";
import { db } from "@/db";
import { destinations, categories, packages } from "@/db/schema";
import { eq } from "drizzle-orm";
import z from "zod";

export const destinationsRouter = createTRPCRouter({
    getAll: baseProcedure.query(async () => {
        const data = await db
            .select({
                id: destinations.id,
                name: destinations.name,
                country: destinations.country,
                region: destinations.region,
                image: destinations.image,
                description: destinations.description,
                packageCount: destinations.packageCount,
                startingPrice: destinations.startingPrice,
                rating: destinations.rating,
                slug: destinations.slug,
                reviewCount: destinations.reviewCount,
                bestTime: destinations.bestTime,
                category: categories.name,
                categorySlug: categories.slug,
            })
            .from(destinations)
            .leftJoin(categories, eq(destinations.categoryId, categories.id));

        return data;
    }),

    getById: baseProcedure
        .input(z.object({ id: z.number() }))
        .query(async ({ input }) => {
            const [destination] = await db
                .select({
                    id: destinations.id,
                    name: destinations.name,
                    country: destinations.country,
                    region: destinations.region,
                    image: destinations.image,
                    description: destinations.description,
                    packageCount: destinations.packageCount,
                    startingPrice: destinations.startingPrice,
                    rating: destinations.rating,
                    reviewCount: destinations.reviewCount,
                    bestTime: destinations.bestTime,
                    category: categories.name,
                    categorySlug: categories.slug,
                })
                .from(destinations)
                .leftJoin(categories, eq(destinations.categoryId, categories.id))
                .where(eq(destinations.id, input.id));

            if (!destination) return null;

            const relatedPackages = await db
                .select({
                    id: packages.id,
                    title: packages.title,
                    image: packages.image,
                    price: packages.price,
                    duration: packages.duration,
                    featured: packages.featured,
                    rating: packages.rating,
                })
                .from(packages)
                .where(eq(packages.destinationId, input.id));

            return {
                ...destination,
                packages: relatedPackages,
            };
        }),
});

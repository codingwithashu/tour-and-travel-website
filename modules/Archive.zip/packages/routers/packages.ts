import { baseProcedure, createTRPCRouter } from "@/trpc/init";
import { db } from "@/db";
import {
    packages,
    destinations,
    categories,
    packageGallery,
    packageInclusions,
    packageExclusions,
    packageHighlights,
    packageItinerary,
    reviews,
} from "@/db/schema";
import { eq, asc, and, or, } from "drizzle-orm";
import z from "zod";

export const packagesRouter = createTRPCRouter({
    // -------------------------
    // Get by Slug (SEO friendly)
    // -------------------------
    getById: baseProcedure
        .input(z.object({ slug: z.string() }))
        .query(async ({ input }) => {
            const [pkg] = await db
                .select({
                    id: packages.id,
                    slug: packages.slug,
                    title: packages.title,
                    description: packages.description,
                    price: packages.price,
                    originalPrice: packages.originalPrice,
                    rating: packages.rating,
                    reviewCount: packages.reviewCount,
                    image: packages.image,
                    featured: packages.featured,
                    duration: packages.duration,
                    destination: destinations.name,
                    category: categories.name,
                })
                .from(packages)
                .leftJoin(destinations, eq(packages.destinationId, destinations.id))
                .leftJoin(categories, eq(packages.categoryId, categories.id))
                .where(eq(packages.slug, input.slug));

            if (!pkg) return null;

            const [
                gallery,
                inclusions,
                exclusions,
                highlights,
                itinerary,
                pkgReviews,
            ] = await Promise.all([
                db
                    .select()
                    .from(packageGallery)
                    .where(eq(packageGallery.packageId, pkg.id)),
                db
                    .select()
                    .from(packageInclusions)
                    .where(eq(packageInclusions.packageId, pkg.id)),
                db
                    .select()
                    .from(packageExclusions)
                    .where(eq(packageExclusions.packageId, pkg.id)),
                db
                    .select()
                    .from(packageHighlights)
                    .where(eq(packageHighlights.packageId, pkg.id)),
                db
                    .select()
                    .from(packageItinerary)
                    .where(eq(packageItinerary.packageId, pkg.id))
                    .orderBy(asc(packageItinerary.dayNumber)),
                db.select().from(reviews).where(eq(reviews.packageId, pkg.id)),
            ]);

            return {
                ...pkg,
                gallery,
                inclusions,
                exclusions,
                highlights,
                itinerary,
                reviews: pkgReviews,
            };
        }),

    // -------------------------
    // Get Featured Packages
    // -------------------------
    getFeaturedAll: baseProcedure.query(async () => {
        const data = await db
            .select({
                id: packages.id,
                slug: packages.slug,
                title: packages.title,
                description: packages.description,
                price: packages.price,
                originalPrice: packages.originalPrice,
                rating: packages.rating,
                reviewCount: packages.reviewCount,
                image: packages.image,
                featured: packages.featured,
                duration: packages.duration,
                destination: destinations.name,
                categoryId: categories.id,
                categoryName: categories.name,
                categorySlug: categories.slug,
            })
            .from(packages)
            .leftJoin(destinations, eq(packages.destinationId, destinations.id))
            .leftJoin(categories, eq(packages.categoryId, categories.id))
            .where(eq(packages.featured, true));

        return data.map((pkg) => ({
            ...pkg,
            category: {
                id: pkg.categoryId,
                name: pkg.categoryName,
                slug: pkg.categorySlug,
            },
        }));
    }),

    // -------------------------
    // Get All (with optional filter)
    // -------------------------
    getAll: baseProcedure
        .input(
            z
                .object({
                    destinationSlug: z.string().optional(),
                    packageSlug: z.string().optional(),
                })
                .optional()
        )
        .query(async ({ input }) => {
            const conditions = [];

            if (input?.destinationSlug) {
                conditions.push(eq(destinations.slug, input.destinationSlug));
            }

            if (input?.packageSlug) {
                conditions.push(eq(packages.slug, input.packageSlug));
            }

            const whereClause =
                conditions.length > 1
                    ? or(...conditions)
                    : conditions.length === 1
                        ? conditions[0]
                        : undefined;

            // Base query
            let query = db
                .select({
                    id: packages.id,
                    slug: packages.slug,
                    title: packages.title,
                    description: packages.description,
                    price: packages.price,
                    originalPrice: packages.originalPrice,
                    rating: packages.rating,
                    reviewCount: packages.reviewCount,
                    image: packages.image,
                    featured: packages.featured,
                    duration: packages.duration,
                    destinationId: destinations.id,
                    destinationSlug: destinations.slug,
                    destinationName: destinations.name,
                    categoryId: categories.id,
                    categoryName: categories.name,
                    categorySlug: categories.slug,
                })
                .from(packages)
                .leftJoin(destinations, eq(packages.destinationId, destinations.id))
                .leftJoin(categories, eq(packages.categoryId, categories.id));

            // Apply filter only if needed
            if (whereClause) {
                query = query.where(whereClause);
            }

            const data = await query;

            // Map result into clean structure
            return data.map((pkg) => ({
                id: pkg.id,
                slug: pkg.slug,
                title: pkg.title,
                description: pkg.description,
                price: pkg.price,
                originalPrice: pkg.originalPrice,
                rating: pkg.rating,
                reviewCount: pkg.reviewCount,
                image: pkg.image,
                featured: pkg.featured,
                duration: pkg.duration,
                destination: pkg.destinationId
                    ? {
                        id: pkg.destinationId,
                        name: pkg.destinationName,
                        slug: pkg.destinationSlug,
                    }
                    : null,
                category: pkg.categoryId
                    ? {
                        id: pkg.categoryId,
                        name: pkg.categoryName,
                        slug: pkg.categorySlug,
                    }
                    : null,
            }));
        }),

});

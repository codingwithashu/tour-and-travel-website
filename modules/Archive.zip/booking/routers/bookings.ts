// trpc/routers/bookings.ts
import { createTRPCRouter, baseProcedure } from "@/trpc/init";
import { db } from "@/db";
import { eq, and } from "drizzle-orm";
import z from "zod";
import { bookings } from "@/db/schema";
import { bookingSchema } from "../schema";


export const bookingsRouter = createTRPCRouter({
    create: baseProcedure
        .input(bookingSchema)
        .mutation(async ({ input }) => {
            // Check for duplicate booking
            const existingBooking = await db
                .select()
                .from(bookings)
                .where(
                    and(
                        eq(bookings.email, input.email),
                        eq(bookings.packageId, input.packageId),
                        eq(bookings.departureDate, input.departureDate),
                        eq(bookings.returnDate, input.returnDate)
                    )
                );
            if (existingBooking.length > 0) {
                throw new Error("You have already booked this package for these dates.");
            }

            // If no duplicate → insert
            const [booking] = await db
                .insert(bookings)
                .values(input)
                .returning();

            return booking;
        }),
    getById: baseProcedure
        .input(z.object({ id: z.number() }))
        .query(async ({ input }) => {
            const [booking] = await db
                .select()
                .from(bookings)
                .where(eq(bookings.id, input.id));
            return booking ?? null;
        }),

    getAll: baseProcedure.query(async () => {
        return db.select().from(bookings);
    }),
});

export type BookingInput = z.infer<typeof bookingSchema>;

import z from "zod";

export const bookingSchema = z.object({
    packageId: z.number(),
    fullName: z.string().min(2),
    email: z.string().email(),
    phone: z.string().min(8),
    departureDate: z.string(),
    returnDate: z.string(),
    travelers: z.number().min(1),
    roomType: z.enum(["single", "double", "suite"]),
});

export type BookingFormData = z.infer<typeof bookingSchema>;